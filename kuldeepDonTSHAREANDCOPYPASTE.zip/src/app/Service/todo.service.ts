import { Injectable } from '@angular/core';
import { TodoModel } from '../Model/TodoModel';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  todoArr:TodoModel[];
idedit:number;
  constructor() {
    this.todoArr=[];
   }

   add(todo:TodoModel){
     todo.Id=Math.floor(Math.random() * 100);
     this.todoArr.push(todo);
   }

   display(){
     return this.todoArr;
   }

   delete(index:number){
     var ans=confirm("are you sure you want to delete ?")
     if(ans){
      this.todoArr.splice(index,1);
     }
     
   }

   edit(id:number){
    var ans=confirm("are you sure you want to edit ?")
    if(ans){
      return this.todoArr.find(x=>x.Id==id);
    }
   }
   set(id:number){
     this.idedit=id;
   }
   get(){
    return this.idedit;
   }

   
}
