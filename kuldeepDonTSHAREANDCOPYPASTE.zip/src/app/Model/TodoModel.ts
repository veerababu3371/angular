export class TodoModel{
    public Id:number;

    public Email:string;
    public password:string;
    public name:string;
    public status:string;

}