import { Component, OnInit } from '@angular/core';
import { TodoModel } from '../Model/TodoModel';
import { TodoService } from '../Service/todo.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
todo:TodoModel;
  constructor(private service:TodoService,private route:Router) {
    this.todo=new TodoModel();
   }
   verify(){
     if (this.todo.Email.match('admin@gmail.com') && this.todo.password.match('123456')) {
       this.route.navigate(['/todo']);
     } else {
      this.route.navigate(['/login']);
     }
   }

  ngOnInit() {
  }

}
